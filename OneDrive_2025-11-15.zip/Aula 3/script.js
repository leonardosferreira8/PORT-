// Botão
const toggle = document.getElementById('toggleMode');

// Verifica no carregamento da página se o modo escuro estava ativado
if (localStorage.getItem("modo") === "dark") {
  document.body.classList.add("dark-mode");
  toggle.textContent = "☀️";
} else {
  toggle.textContent = "🌙";
}

// Evento de clique para alternar o modo
toggle.addEventListener('click', () => {
  document.body.classList.toggle('dark-mode');

  // Se o modo escuro ativar, salvar no localStorage
  if (document.body.classList.contains("dark-mode")) {
    localStorage.setItem("modo", "dark");
    toggle.textContent = "☀️";
  } else {
    localStorage.setItem("modo", "light");
    toggle.textContent = "🌙";
  }
});
